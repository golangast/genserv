#!/bin/bash

go build -o app
rm app
