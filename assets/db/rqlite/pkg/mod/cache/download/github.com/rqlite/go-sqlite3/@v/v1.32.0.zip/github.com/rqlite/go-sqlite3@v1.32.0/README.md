go-sqlite3
==========

[![Circle CI](https://circleci.com/gh/rqlite/go-sqlite3/tree/master.svg?style=svg)](https://circleci.com/gh/rqlite/go-sqlite3/tree/master)

See upstream for README.
