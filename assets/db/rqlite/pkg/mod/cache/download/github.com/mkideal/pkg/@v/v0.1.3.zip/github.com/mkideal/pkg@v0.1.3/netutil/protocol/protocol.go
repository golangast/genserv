package protocol

const (
	UDP        = "udp"
	TCP        = "tcp"
	HTTP       = "http"
	HTTPS      = "https"
	Websocket  = "ws"
	WebsocketS = "wss"
)
