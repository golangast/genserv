# PKG [![License](http://img.shields.io/badge/license-mit-blue.svg?style=flat-square)](https://raw.githubusercontent.com/mkideal/pkg/master/LICENSE)

## License

[The MIT License (MIT)](https://raw.githubusercontent.com/mkideal/pkg/master/LICENSE)

`pkg` contains some utility packages.

