# rqlite-disco-clients
[![Circle CI](https://circleci.com/gh/rqlite/rqlite-disco-clients/tree/main.svg?style=svg)](https://circleci.com/gh/rqlite/rqlite-disco-clients/tree/main) [![Go Report Card](https://goreportcard.com/badge/github.com/rqlite/rqlite-disco-clients)](https://goreportcard.com/report/github.com/rqlite/rqlite-disco-clients)

This repo contains client code for various node-discovery mechanisms, which [rqlite](https://github.com/rqlite/rqlite) uses for autoclustering and discovery.
